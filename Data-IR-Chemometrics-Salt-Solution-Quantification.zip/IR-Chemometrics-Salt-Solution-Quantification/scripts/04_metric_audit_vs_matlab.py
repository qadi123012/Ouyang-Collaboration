"""What do the numbers printed by the MATLAB scripts actually measure?

The MATLAB PLS scripts (matlab/pls_*.m) fit a joint PLS2 model on ALL samples of the sheet (R and Y together,
raw mean-centred spectra), choose the number of components by 5-fold CV, and then print R^2 / RMSE of the
FITTED data. That is a training-set (resubstitution) statistic. This script reproduces that recipe in Python
and sets it beside leave-one-composition-out CV and external validation on the Y samples.

Also quantifies the 'labels x 2' hypothesis for the ammonium sulfate validation set (diagnostic, not a result).

Outputs: results/tables/metric_audit_matlab_style_vs_honest.csv, results/tables/sulfate_scale_hypothesis.csv
"""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import pandas as pd
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import KFold
from irchem import io, evaluation as E
from irchem.models import PLS1

TAB = ROOT / "results" / "tables"
best = pd.read_csv(TAB / "benchmark_best_pipeline.csv")
rows = []
for key in io.PRIMARY:
    ds = io.load(key)
    X, Y = ds.X, ds.Y
    n = len(X)
    # --- MATLAB-style: all samples, raw spectra, PLS2, 5-fold CV (random folds) picks the number of components
    kmax = min(10, n - 2)
    mse = []
    for k in range(1, kmax + 1):
        err = 0.0
        for tr, te in KFold(5, shuffle=True, random_state=0).split(X):
            m = PLSRegression(k, scale=False).fit(X[tr], Y[tr])
            err += np.sum((m.predict(X[te]) - Y[te]) ** 2) / (5 * len(te))
        mse.append(err)
    k_m = int(np.argmin(mse)) + 1
    fit = PLSRegression(k_m, scale=False).fit(X, Y).predict(X)
    for j, comp in enumerate(ds.components):
        b = best[(best.dataset == key) & (best.analyte == comp)].iloc[0]
        rows.append(dict(dataset=key, analyte=comp,
                         matlab_style_n_components=k_m,
                         matlab_style_train_R2=E.r2(Y[:, j], fit[:, j]),
                         matlab_style_train_RMSE=E.rmse(Y[:, j], fit[:, j]),
                         honest_pipeline=b.pipeline, honest_n_components=int(b.n_components),
                         honest_RMSEC=b.rmsec, honest_RMSECV=b.rmsecv, honest_R2_cv=b.r2_cv,
                         honest_RMSEP=b.rmsep, honest_R2_val=b.r2_val,
                         rmse_of_predicting_the_mean_on_validation=b.rmsep_mean_baseline))
a = pd.DataFrame(rows)
a.to_csv(TAB / "metric_audit_matlab_style_vs_honest.csv", index=False)
pd.set_option("display.width", 250)
print(a[["dataset", "analyte", "matlab_style_n_components", "matlab_style_train_R2", "honest_R2_cv", "honest_R2_val",
         "honest_RMSEP", "rmse_of_predicting_the_mean_on_validation"]].round(3).to_string(index=False))

# --- sulfate scale hypothesis (diagnostic): rescale validation labels by 2 and recompute RMSEP
pr = pd.read_csv(TAB / "predictions_primary_systems.csv")
s = pr[(pr.dataset == "ammonium_sulfate") & (pr.subset == "validation")]
out = []
for comp, g in s.groupby("analyte"):
    for f in (1.0, 2.0):
        out.append(dict(analyte=comp, label_scale_factor=f, rmsep=E.rmse(g.true_mol_L * f, g.predicted_mol_L),
                        r2=E.r2(g.true_mol_L * f, g.predicted_mol_L),
                        slope=float(np.polyfit(g.true_mol_L * f, g.predicted_mol_L, 1)[0])))
o = pd.DataFrame(out); o.to_csv(TAB / "sulfate_scale_hypothesis.csv", index=False)
print("\nAmmonium sulfate validation, labels as given (x1) versus multiplied by 2 (hypothesis only):")
print(o.round(3).to_string(index=False))
