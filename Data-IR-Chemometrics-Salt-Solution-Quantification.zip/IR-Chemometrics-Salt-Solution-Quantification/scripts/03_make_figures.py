"""Figures and per-spectrum predictions for the four primary systems, using the pipeline chosen by CV.

Needs results/tables/benchmark_best_pipeline.csv (run 02 first).
Outputs: results/figures/F2..F7 and results/tables/predictions_primary_systems.csv
"""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from irchem import io, preprocessing as P, evaluation as E
from irchem.models import PLS1

FIG = ROOT / "results" / "figures"; TAB = ROOT / "results" / "tables"
best = pd.read_csv(TAB / "benchmark_best_pipeline.csv")
allp = pd.read_csv(TAB / "benchmark_all_pipelines.csv")


def parse(label):
    s, r, c, d = label.split("|")
    return P.Pipeline(s, c, int(d[1:]), r)


fits, preds, curves = {}, [], {}
for key in io.PRIMARY:
    ds = io.load(key)
    pl = parse(best[best.dataset == key].pipeline.iloc[0])
    w, Z = pl.apply(ds.wn, ds.X)
    cal, val = ds.is_cal, ds.is_val
    for j, comp in enumerate(ds.components):
        y = ds.Y[:, j]
        k = int(best[(best.dataset == key) & (best.analyte == comp)].n_components.iloc[0])
        curves[(key, comp)] = (E.pls_cv_curve(Z[cal], y[cal], ds.groups[cal]), k)
        m = PLS1(k).fit(Z[cal], y[cal])
        cvp = E.logo_predict(lambda: PLS1(k), Z[cal], y[cal], ds.groups[cal])
        fits[(key, comp)] = dict(ds=ds, pl=pl, w=w, Z=Z, k=k, model=m, cvp=cvp, y=y)
        for i, idx in enumerate(np.where(cal)[0]):
            preds.append((key, comp, ds.names[idx], "calibration (LOCO-CV)", y[idx], cvp[i]))
        for idx in np.where(val)[0]:
            preds.append((key, comp, ds.names[idx], "validation", y[idx], float(m.predict(Z[idx:idx + 1])[0])))
pd.DataFrame(preds, columns=["dataset", "analyte", "spectrum", "subset", "true_mol_L", "predicted_mol_L"]) \
    .to_csv(TAB / "predictions_primary_systems.csv", index=False)

keys = list(fits)
# ---- F2 CV curves
fig, ax = plt.subplots(3, 3, figsize=(13, 10)); ax = ax.ravel()
for a, kk in zip(ax, keys):
    c, k = curves[kk]
    a.plot(range(1, len(c) + 1), c, "o-"); a.plot(k, c[k - 1], "rs", ms=10, label=f"chosen: {k}")
    a.axhline(fits[kk]["ds"].Y[fits[kk]["ds"].is_cal, list(fits[kk]["ds"].components).index(kk[1])].std(ddof=1),
              color="0.5", ls=":", label="SD of calibration y")
    a.set_title(f"{kk[1]}  [{kk[0]}]", fontsize=10); a.set_xlabel("latent variables"); a.set_ylabel("RMSECV (mol/L)")
    a.legend(fontsize=8); a.grid(alpha=.3)
for a in ax[len(keys):]:
    a.axis("off")
fig.suptitle("Leave-one-composition-out RMSECV versus model size (dotted: error of predicting the mean)")
fig.tight_layout(); fig.savefig(FIG / "F2_cv_curves.png", dpi=150); plt.close(fig)

# ---- F3 parity plots
fig, ax = plt.subplots(3, 3, figsize=(13, 12)); ax = ax.ravel()
for a, kk in zip(ax, keys):
    f = fits[kk]; ds = f["ds"]; cal, val = ds.is_cal, ds.is_val
    y = f["y"]; lim = [0, max(y.max(), f["cvp"].max()) * 1.1]
    a.plot(lim, lim, "k--", lw=1)
    a.scatter(y[cal], f["cvp"], c="C0", label="calibration, LOCO-CV")
    pv = f["model"].predict(f["Z"][val])
    a.scatter(y[val], pv, c="C3", marker="^", label="validation (unseen)")
    row = best[(best.dataset == kk[0]) & (best.analyte == kk[1])].iloc[0]
    a.set_title(f"{kk[1]} [{kk[0]}]\nRMSECV {row.rmsecv:.3f}  RMSEP {row.rmsep:.3f}  (mean-baseline {row.rmsep_mean_baseline:.3f})", fontsize=9)
    a.set_xlabel("labelled concentration (mol/L)"); a.set_ylabel("predicted (mol/L)"); a.grid(alpha=.3)
    a.set_xlim(lim); a.set_ylim(min(0, min(pv.min(), f["cvp"].min()) * 1.1), max(lim[1], pv.max() * 1.1))
    a.legend(fontsize=7, loc="upper left")
for a in ax[len(keys):]:
    a.axis("off")
fig.suptitle("Predicted versus labelled concentration (best CV pipeline per system)")
fig.tight_layout(); fig.savefig(FIG / "F3_parity_plots.png", dpi=150); plt.close(fig)

# ---- F4 heatmap: validation RMSEP relative to the mean predictor, all pipelines
v = allp[allp.dataset.isin(io.PRIMARY) & allp.n_val.notna()].copy()
v["ratio"] = v.rmsep / v.rmsep_mean_baseline
tab = v.groupby(["dataset", "pipeline"]).ratio.mean().unstack(0)[io.PRIMARY]
tab = tab.sort_values(io.PRIMARY[1])
fig, ax = plt.subplots(figsize=(8, 10))
im = ax.imshow(np.log10(tab.values), cmap="RdYlGn_r", vmin=-1.5, vmax=1.0, aspect="auto")
ax.set_xticks(range(len(tab.columns))); ax.set_xticklabels(tab.columns, rotation=20)
ax.set_yticks(range(len(tab))); ax.set_yticklabels(tab.index, fontsize=7)
for i in range(tab.shape[0]):
    for j in range(tab.shape[1]):
        ax.text(j, i, f"{tab.values[i, j]:.2f}", ha="center", va="center", fontsize=6)
fig.colorbar(im, ax=ax, label="log10( RMSEP / error of predicting the mean )")
ax.set_title("Validation error relative to the mean predictor\n(values below 1 beat it; mean over analytes)")
fig.tight_layout(); fig.savefig(FIG / "F4_pipeline_heatmap.png", dpi=150); plt.close(fig)

# ---- F5 sulfate scale diagnostic
fig, ax = plt.subplots(1, 2, figsize=(12, 5))
for a, comp in zip(ax, io.load("ammonium_sulfate").components):
    f = fits[("ammonium_sulfate", comp)]; ds = f["ds"]; val = ds.is_val
    pv = f["model"].predict(f["Z"][val]); yv = f["y"][val]
    sl, ic = np.polyfit(yv, pv, 1)
    a.plot(yv, pv, "r^", label="validation spectra")
    a.plot([0, 2.2], [0, 2.2], "k--", label="1:1")
    a.plot([0, 1], [ic, sl + ic], "r-", lw=1, label=f"fit: slope {sl:.2f}, r = {np.corrcoef(yv, pv)[0, 1]:.3f}")
    a.plot(yv * 2, pv, "o", mfc="none", c="C2", label="labels x 2 (hypothesis)")
    a.set_xlabel("labelled concentration (mol/L)"); a.set_ylabel("predicted (mol/L)"); a.set_title(comp)
    a.legend(fontsize=8); a.grid(alpha=.3)
fig.suptitle("(NH4)2SO4 + NH4HSO4: predictions track the labels almost perfectly but about 2x too large")
fig.tight_layout(); fig.savefig(FIG / "F5_sulfate_scale_diagnostic.png", dpi=150); plt.close(fig)

# ---- F6 regression coefficients
fig, ax = plt.subplots(4, 1, figsize=(12, 13))
for a, key in zip(ax, io.PRIMARY):
    ds = io.load(key)
    for comp in ds.components:
        f = fits[(key, comp)]
        c = f["model"].coef
        a.plot(f["w"], c / np.abs(c).max(), lw=1, label=f"{comp} (k={f['k']})")
    a.set_title(f"{ds.title}: PLS regression coefficients, {fits[(key, ds.components[0])]['pl'].label}", fontsize=10)
    a.set_xlabel("Wavenumber (cm$^{-1}$)"); a.set_ylabel("coefficient / max"); a.invert_xaxis(); a.legend(fontsize=8); a.grid(alpha=.3)
fig.tight_layout(); fig.savefig(FIG / "F6_regression_coefficients.png", dpi=150); plt.close(fig)

# ---- F7 PCA scores
fig, ax = plt.subplots(2, 2, figsize=(11, 9)); ax = ax.ravel()
for a, key in zip(ax, io.PRIMARY):
    f = fits[(key, io.load(key).components[0])]; ds = f["ds"]; Z = f["Z"]; cal, val = ds.is_cal, ds.is_val
    mu = Z[cal].mean(0); U, S, Vt = np.linalg.svd(Z[cal] - mu, full_matrices=False)
    sc = lambda M: (M - mu) @ Vt[:2].T
    a.scatter(*sc(Z[cal]).T, c="C0", label="calibration")
    a.scatter(*sc(Z[val]).T, c="C3", marker="^", label="validation")
    ev = S ** 2 / np.sum(S ** 2)
    a.set_xlabel(f"PC1 ({100*ev[0]:.0f} %)"); a.set_ylabel(f"PC2 ({100*ev[1]:.0f} %)"); a.set_title(ds.title); a.legend(); a.grid(alpha=.3)
fig.suptitle("Do the validation spectra sit inside the calibration space? (PCA of calibration spectra)")
fig.tight_layout(); fig.savefig(FIG / "F7_pca_calibration_vs_validation.png", dpi=150); plt.close(fig)
print("figures written to", FIG)
