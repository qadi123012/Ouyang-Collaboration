"""Benchmark PLS regression over a grid of pre-processing choices, for every dataset.

Protocol (no information from the validation samples is used for any choice):
  1. calibration set  = R samples,   validation set = Y samples (when present)
  2. for each pre-processing pipeline and each analyte, leave-one-COMPOSITION-out CV on the calibration set
     (standards prepared at identical concentrations are held out together) gives RMSECV for 1..8 latent
     variables; the smallest number within 5 % of the minimum is used (parsimony rule)
  3. the final PLS model is fitted on ALL calibration spectra and used once on the validation set (RMSEP)
  4. the pipeline reported as 'best' is the one with the lowest normalised RMSECV (selection on CV only);
     validation results of every pipeline are still tabulated so the reader can see how well CV predicts them

Outputs: results/tables/benchmark_all_pipelines.csv, benchmark_best_pipeline.csv
Usage:   python scripts/02_run_benchmark.py [--datasets k2co3_khco3 oxalate ...]
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import argparse
import numpy as np
import pandas as pd
from irchem import io, preprocessing as P, evaluation as E
from irchem.models import PLS1, Univariate, MeanBaseline

ap = argparse.ArgumentParser()
ap.add_argument("--datasets", nargs="*", default=list(io.REGISTRY))
ap.add_argument("--out", default=str(pathlib.Path(__file__).resolve().parents[1] / "results" / "tables"))
a = ap.parse_args()
out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)

rows = []
for key in a.datasets:
    ds = io.load(key)
    cal, val = ds.is_cal, ds.is_val
    g = ds.groups
    print(f"== {key}: {cal.sum()} calibration spectra, {val.sum()} validation spectra", flush=True)
    for pl in P.grid():
        w, Z = pl.apply(ds.wn, ds.X)
        for j, comp in enumerate(ds.components):
            y = ds.Y[:, j]
            ycal = y[cal]
            curve = E.pls_cv_curve(Z[cal], ycal, g[cal])
            k = E.choose_k(curve)
            m = PLS1(k).fit(Z[cal], ycal)
            fit = E.metrics(ycal, m.predict(Z[cal]))
            cvp = E.logo_predict(lambda: PLS1(k), Z[cal], ycal, g[cal])
            cv = E.metrics(ycal, cvp)
            row = dict(dataset=key, pipeline=pl.label, signal=pl.signal, region=pl.region, scatter=pl.scatter,
                       deriv=pl.deriv, analyte=comp, n_features=Z.shape[1], n_cal=int(cal.sum()),
                       n_components=k, cal_sd=float(np.std(ycal, ddof=1)),
                       rmsec=fit["rmse"], r2_cal=fit["r2"], rmsecv=cv["rmse"], r2_cv=cv["r2"],
                       rmsecv_mean_baseline=E.rmse(ycal, E.logo_predict(MeanBaseline, Z[cal], ycal, g[cal])))
            # baselines: mean predictor and best single wavenumber (selected inside every fold)
            uv = E.logo_predict(Univariate, Z[cal], ycal, g[cal])
            row.update(rmsecv_univariate=E.rmse(ycal, uv))
            if val.any():
                pv = m.predict(Z[val]); mv = E.metrics(y[val], pv)
                base = E.rmse(y[val], np.full(val.sum(), ycal.mean()))
                row.update(n_val=int(val.sum()), rmsep=mv["rmse"], r2_val=mv["r2"], bias_val=mv["bias"],
                           mae_val=mv["mae"], rmsep_mean_baseline=base,
                           rmsep_univariate=E.rmse(y[val], Univariate().fit(Z[cal], ycal).predict(Z[val])))
                # does the validation set follow the calibration scale? slope of predicted vs labelled
                if np.ptp(y[val]) > 0:
                    sl, ic = np.polyfit(y[val], pv, 1)
                    row.update(corr_val=float(np.corrcoef(y[val], pv)[0, 1]), slope_val=float(sl), intercept_val=float(ic))
            rows.append(row)
df = pd.DataFrame(rows)
df["rmsecv_norm"] = df["rmsecv"] / df["cal_sd"]
df.to_csv(out / "benchmark_all_pipelines.csv", index=False)

# best pipeline per dataset: lowest mean normalised RMSECV over analytes (CV only)
agg = df.groupby(["dataset", "pipeline"])["rmsecv_norm"].mean().reset_index()
best_pipe = agg.loc[agg.groupby("dataset")["rmsecv_norm"].idxmin()][["dataset", "pipeline"]]
best = df.merge(best_pipe, on=["dataset", "pipeline"])
best.to_csv(out / "benchmark_best_pipeline.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
cols = ["dataset", "pipeline", "analyte", "n_components", "rmsec", "rmsecv", "r2_cv", "rmsep", "r2_val", "rmsep_mean_baseline"]
print(best[[c for c in cols if c in best.columns]].round(3).to_string(index=False))
