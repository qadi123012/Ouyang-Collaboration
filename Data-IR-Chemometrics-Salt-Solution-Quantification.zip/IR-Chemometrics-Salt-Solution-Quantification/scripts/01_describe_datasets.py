"""Build the data catalogue and the raw-spectra overview figure.

Outputs: results/tables/data_catalogue.csv, results/figures/F1_spectra_overview.png
"""
import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from irchem import io, preprocessing as P

(ROOT / "results" / "tables").mkdir(parents=True, exist_ok=True)
(ROOT / "results" / "figures").mkdir(parents=True, exist_ok=True)
rows = [io.describe(io.load(k)) for k in io.REGISTRY]
cat = pd.DataFrame(rows)
cat.to_csv(ROOT / "results" / "tables" / "data_catalogue.csv", index=False)
print(cat[["key", "status", "spectra", "calibration_spectra", "validation_spectra", "wn_min", "wn_max", "removed_windows"]].to_string(index=False))

# Do the earlier K2CO3/KHCO3 files contain the same spectra as the corrected file?
v3, v2 = io.load("k2co3_khco3"), io.load("k2co3_khco3_v2")
common = np.isin(np.round(v2.wn, 3), np.round(v3.wn, 3))
cmp = []
for n in [x for x in v3.names if x in v2.names]:
    a = v3.X[v3.names.index(n)]; b = v2.X[v2.names.index(n)][common]
    cmp.append((n, float(np.max(np.abs(a - b))), tuple(v3.Y[v3.names.index(n)]), tuple(v2.Y[v2.names.index(n)])))
diff = pd.DataFrame(cmp, columns=["spectrum", "max_abs_signal_difference", "label_v3_corrected", "label_v2_earlier"])
diff["label_changed"] = diff.label_v3_corrected != diff.label_v2_earlier
diff.to_csv(ROOT / "results" / "tables" / "k2co3_khco3_label_comparison_v2_vs_v3.csv", index=False)
print("\nK2CO3/KHCO3 v2 vs v3 (same spectra, different labels?):")
print(diff.round(4).to_string(index=False))

# overview figure: raw spectra of the four primary systems, coloured by total concentration
fig, ax = plt.subplots(2, 2, figsize=(14, 9))
for a, key in zip(ax.ravel(), io.PRIMARY):
    ds = io.load(key)
    tot = ds.Y.sum(axis=1)
    cmap = plt.cm.viridis
    for x, t in zip(ds.X, tot):
        a.plot(ds.wn, x, color=cmap(t / tot.max()), lw=0.9)
    a.axvspan(*P.CO2_WINDOW, color="r", alpha=0.12, label="CO2 window (2220-2430)")
    a.set_title(ds.title); a.set_xlabel("Wavenumber (cm$^{-1}$)"); a.set_ylabel("Recorded signal (% scale)")
    a.invert_xaxis(); a.grid(alpha=.3)
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=plt.Normalize(0, tot.max())); fig.colorbar(sm, ax=a, label="total concentration (mol/L)")
ax[0, 0].legend(loc="lower left")
fig.suptitle("Raw spectra of the four main systems (bands appear as dips: the signal behaves like % transmittance)")
fig.tight_layout(); fig.savefig(ROOT / "results" / "figures" / "F1_spectra_overview.png", dpi=150)
print("saved figure")
