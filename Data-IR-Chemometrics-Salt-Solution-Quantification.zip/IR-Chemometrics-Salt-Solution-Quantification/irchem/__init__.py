"""irchem: chemometric quantification of mixed salt solutions from infrared spectra."""
import warnings as _w
# sklearn warns when more latent variables are requested than the data rank supports; the cross-validation
# curve already shows where extra components stop helping, so the warning is just noise here.
_w.filterwarnings("ignore", message="y residual is constant", category=UserWarning)
__version__ = "1.0.0"
