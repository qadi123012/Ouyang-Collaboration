"""Spectral pre-processing: signal conversion, region selection, SNV, Savitzky-Golay, IPF baseline.

The recorded values look like PERCENT TRANSMITTANCE (baseline about 97-100 outside the bands, bands appear as
dips). Beer-Lambert is linear in absorbance, A = -log10(T/100), so `to_absorbance` is offered as an option and
compared with the raw signal in the benchmark.
"""
from dataclasses import dataclass
import numpy as np
from scipy.signal import savgol_filter

CO2_WINDOW = (2220.0, 2430.0)        # atmospheric CO2 asymmetric stretch; the raw files show a spike near 2350
REGIONS = {
    "full": [(650.0, 4000.5)],        # everything above the crystal cut-off, minus the CO2 window
    "wide": [(650.0, 2000.0)],
    "fingerprint": [(800.0, 1800.0)],
}


def to_absorbance(T, floor=0.5):
    """A = -log10(T/100). Values below `floor` percent are clipped to avoid log(0)."""
    return -np.log10(np.clip(T, floor, None) / 100.0)


def _segments(wn, max_step=3.0):
    """Index slices of contiguous stretches (a removed window creates a new segment)."""
    cuts = np.where(np.diff(wn) > max_step)[0] + 1
    return np.split(np.arange(len(wn)), cuts)


def savgol_per_segment(wn, X, window=15, poly=2, deriv=1):
    out = np.empty_like(X, dtype=float)
    for seg in _segments(wn):
        w = min(window, (len(seg) // 2) * 2 - 1)
        out[:, seg] = savgol_filter(X[:, seg], w, poly, deriv=deriv, axis=1)
    return out


def snv(X):
    """Standard normal variate, per spectrum."""
    return (X - X.mean(axis=1, keepdims=True)) / X.std(axis=1, ddof=1, keepdims=True)


def select_region(wn, X, region="full", exclude_co2=True):
    keep = np.zeros(len(wn), bool)
    for lo, hi in REGIONS[region]:
        keep |= (wn >= lo) & (wn <= hi)
    if exclude_co2:
        keep &= ~((wn >= CO2_WINDOW[0]) & (wn <= CO2_WINDOW[1]))
    return wn[keep], X[:, keep]


def ipf_baseline(x, y, degree=2, max_iter=100, tol=1e-6):
    """Iterative polynomial fit baseline (port of the MATLAB `ipf_baseline`)."""
    p = np.polyfit(x, y, degree)
    base = np.polyval(p, x)
    for _ in range(max_iter):
        res = y - base
        idx = np.abs(res) < 2 * res.std()
        p = np.polyfit(x[idx], y[idx], degree)
        new = np.polyval(p, x)
        if np.linalg.norm(new - base) < tol:
            break
        base = new
    return base


@dataclass(frozen=True)
class Pipeline:
    signal: str = "T"            # "T" as recorded, "A" absorbance
    scatter: str = "none"        # "none" or "snv"
    deriv: int = 0               # 0 or 1 (Savitzky-Golay, window 15, 2nd order)
    region: str = "full"         # key of REGIONS

    @property
    def label(self):
        return f"{self.signal}|{self.region}|{self.scatter}|d{self.deriv}"

    def apply(self, wn, X):
        """Return (wavenumbers, processed matrix). Derivatives are taken on the full axis first."""
        Z = to_absorbance(X) if self.signal == "A" else np.asarray(X, float)
        if self.deriv:
            Z = savgol_per_segment(wn, Z, deriv=self.deriv)
        w, Z = select_region(wn, Z, self.region)
        if self.scatter == "snv":
            Z = snv(Z)
        return w, Z


def grid(signals=("T", "A"), scatters=("none", "snv"), derivs=(0, 1), regions=("full", "wide", "fingerprint")):
    return [Pipeline(s, c, d, r) for s in signals for r in regions for c in scatters for d in derivs]
