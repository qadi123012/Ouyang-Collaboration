"""Dataset registry and loader for the Excel files in data/raw.

All raw workbooks share one layout on `Sheet1`:

    name | <conc columns> | [Total] | Wavenumber | <one column per spectrum>

The first rows of the sheet carry the sample table (`name` + concentrations) and,
in the SAME rows, the first spectral points. Spectral columns are called R1..R17
(calibration standards) and Y1..Y9 (validation samples); triplicate files use
R1-1, R1-2, R1-3, and so on.

IMPORTANT: several workbooks still carry the header `c_K2CO3` / `c_KHCO3` as a
template even though the solution is ammonium sulfate / bisulfate or potassium
oxalate / hydrogen oxalate. The registry below states the real chemistry from the
file name; the concentration columns are read by POSITION (first = component 1).
"""
from dataclasses import dataclass, field
from pathlib import Path
import re
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"

# key -> (relative path, title, component labels, status, note)
REGISTRY = {
    "k2co3_khco3": ("k2co3_khco3/k2co3_khco3_v3_corrected.xlsx",
                    "K2CO3 + KHCO3", ["K2CO3", "KHCO3"], "primary",
                    "Corrected sample table (R3, R4, R10 are blanks)."),
    "oxalate": ("potassium_oxalate/k2c2o4_khc2o4.xlsx",
                "K2C2O4 + KHC2O4", ["K2C2O4", "KHC2O4"], "primary",
                "Headers in the file still read c_K2CO3 / c_KHCO3."),
    "ammonium_sulfate": ("ammonium_sulfate_bisulfate/as_abs_v3_full_range.xlsx",
                         "(NH4)2SO4 + NH4HSO4", ["(NH4)2SO4", "NH4HSO4"], "primary",
                         "Headers in the file still read c_K2CO3 / c_KHCO3. Y1-Y9 are a mixing line at constant total 1.0 mol/L."),
    "phosphate": ("sodium_phosphate/na3po4_na2hpo4_nah2po4.xlsx",
                  "Na3PO4 + Na2HPO4 + NaH2PO4", ["Na3PO4", "Na2HPO4", "NaH2PO4"], "primary",
                  "Three components. Header unit says (absorbtion, unit:%)."),
    "k2co3_khco3_v2": ("k2co3_khco3/k2co3_khco3_v2_extended_range.xlsx",
                       "K2CO3 + KHCO3 (earlier version, 399-4000 cm-1)", ["K2CO3", "KHCO3"], "earlier version",
                       "Sample table differs from the corrected file (R3 and R10 are 0.75/0.75 here, blanks there)."),
    "k2co3_khco3_v1": ("k2co3_khco3/k2co3_khco3_v1_original_900-2000.xlsx",
                       "K2CO3 + KHCO3 (original, 900-2000 cm-1)", ["K2CO3", "KHCO3"], "earlier version",
                       "Narrow window only."),
    "as_abs_cuta": ("ammonium_sulfate_bisulfate/as_abs_v2_co2_window_removed.xlsx",
                    "(NH4)2SO4 + NH4HSO4, CO2 window removed", ["(NH4)2SO4", "NH4HSO4"], "variant",
                    "2222-2434 cm-1 removed."),
    "as_abs_cut": ("ammonium_sulfate_bisulfate/as_abs_v1_874-984_removed.xlsx",
                   "(NH4)2SO4 + NH4HSO4, 874-984 cm-1 removed", ["(NH4)2SO4", "NH4HSO4"], "variant",
                   "A window inside the fingerprint region is missing."),
    "as_abs_4p1": ("ammonium_sulfate_bisulfate/as_abs_4p1_R_only.xlsx",
                   "(NH4)2SO4 + NH4HSO4, calibration only", ["(NH4)2SO4", "NH4HSO4"], "variant",
                   "R1-R11 only, no validation samples."),
    "as_abs_4p1_cut": ("ammonium_sulfate_bisulfate/as_abs_4p1_R_only_co2_window_removed.xlsx",
                       "(NH4)2SO4 + NH4HSO4, calibration only, CO2 window removed", ["(NH4)2SO4", "NH4HSO4"],
                       "variant", "R1-R11 only."),
    "as_abs_4p6": ("ammonium_sulfate_bisulfate/as_abs_4p6_water_background_triplicates.xlsx",
                   "(NH4)2SO4 + NH4HSO4, triplicates (water background)", ["(NH4)2SO4", "NH4HSO4"], "variant",
                   "Each standard measured 3 times (R1-1 ... R11-3), CO2 window removed. Spectra scaled differently (baseline ~98)."),
}
PRIMARY = [k for k, v in REGISTRY.items() if v[3] == "primary"]


@dataclass
class Dataset:
    key: str
    title: str
    components: list
    wn: np.ndarray                 # (p,) wavenumber, cm-1, ascending
    X: np.ndarray                  # (n, p) signal exactly as recorded
    Y: np.ndarray                  # (n, k) concentrations, mol/L
    names: list                    # (n,) spectrum names, e.g. R1, R1-2, Y3
    groups: np.ndarray             # (n,) integer id of the COMPOSITION (identical concentration vectors share an id)
    is_cal: np.ndarray             # (n,) bool, R samples
    is_val: np.ndarray             # (n,) bool, Y samples
    samples: list = field(default_factory=list)   # (n,) physical sample id, e.g. R1, Y3 (replicates share it)
    notes: str = ""
    meta: dict = field(default_factory=dict)

    @property
    def n_samples(self):
        return len(set(self.samples))

    @property
    def n_compositions(self):
        return len(set(self.groups))


def _sample_id(col):
    m = re.match(r"^\s*([RY]\d+)", str(col))
    return m.group(1) if m else None


def load(key):
    rel, title, comps, status, note = REGISTRY[key]
    d = pd.read_excel(RAW / rel, sheet_name="Sheet1")
    d.columns = [str(c).strip() for c in d.columns]
    cols = list(d.columns)
    wcol = next(c for c in cols if c.lower().startswith("wavenumber"))
    wi = cols.index(wcol)
    # concentration columns: between 'name' and 'Wavenumber', excluding total-like columns
    conc_cols = [c for c in cols[1:wi] if not re.search(r"total|sum\(", c, re.I)]
    assert len(conc_cols) == len(comps), (key, conc_cols)
    meta = d[d["name"].notna()].copy()
    meta["name"] = meta["name"].astype(str).str.strip()
    sample_names = list(meta["name"])
    conc = {n: meta.loc[meta["name"] == n, conc_cols].iloc[0].astype(float).values for n in sample_names}

    spec_cols = [c for c in cols[wi + 1:] if _sample_id(c) in conc]
    wn_all = d[wcol].astype(float).values
    ok = np.isfinite(wn_all)
    wn = wn_all[ok]
    order = np.argsort(wn)
    X = np.stack([d.loc[ok, c].astype(float).values[order] for c in spec_cols])
    names = [str(c).strip() for c in spec_cols]
    sid = [_sample_id(c) for c in spec_cols]
    Y = np.stack([conc[s] for s in sid])
    # Groups are COMPOSITIONS, not spectra: standards that were prepared at the same concentrations (centre points)
    # must be held out together, otherwise leave-one-out cross-validation keeps a near duplicate in training.
    comp_key = [tuple(np.round(y, 6)) for y in Y]
    ids = {c: i for i, c in enumerate(dict.fromkeys(comp_key))}
    groups = np.array([ids[c] for c in comp_key])
    is_cal = np.array([s.startswith("R") for s in sid])
    is_val = np.array([s.startswith("Y") for s in sid])
    return Dataset(key, title, comps, wn[order], X, Y, names, groups, is_cal, is_val, samples=sid,
                   notes=note, meta=dict(status=status, file=rel, conc_columns_in_file=conc_cols))


def describe(ds):
    """One-line facts used by the data catalogue."""
    dw = np.diff(ds.wn)
    gaps = [(round(float(ds.wn[i]), 0), round(float(ds.wn[i + 1]), 0)) for i in np.where(dw > 3.0)[0]]
    return dict(key=ds.key, system=ds.title, status=ds.meta["status"], file=ds.meta["file"],
                spectra=len(ds.names), samples=ds.n_samples,
                compositions_in_calibration=len(set(ds.groups[ds.is_cal])),
                calibration_spectra=int(ds.is_cal.sum()), validation_spectra=int(ds.is_val.sum()),
                points=len(ds.wn), wn_min=round(float(ds.wn.min()), 1), wn_max=round(float(ds.wn.max()), 1),
                removed_windows=str(gaps) if gaps else "none",
                signal_min=round(float(ds.X.min()), 1), signal_max=round(float(ds.X.max()), 1),
                conc_max=[round(float(v), 3) for v in ds.Y.max(axis=0)], note=ds.notes)
