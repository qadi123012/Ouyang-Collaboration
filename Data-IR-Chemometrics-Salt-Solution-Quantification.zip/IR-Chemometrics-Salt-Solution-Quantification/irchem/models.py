"""Calibration models: PLS regression (one model per analyte), univariate band calibration, mean baseline."""
import numpy as np
from sklearn.cross_decomposition import PLSRegression


class PLS1:
    """PLS regression for ONE analyte. X and y are mean-centred inside `fit`."""
    def __init__(self, n_components=3):
        self.k = n_components

    def fit(self, X, y):
        self.m = PLSRegression(n_components=self.k, scale=False).fit(X, y)
        return self

    def predict(self, X):
        return np.asarray(self.m.predict(X)).ravel()

    @property
    def coef(self):
        return np.asarray(self.m.coef_).ravel()


class Univariate:
    """Best single wavenumber chosen by |correlation| on the TRAINING data only, then a straight line."""
    def fit(self, X, y):
        Xc, yc = X - X.mean(0), y - y.mean()
        den = np.sqrt((Xc ** 2).sum(0) * (yc ** 2).sum()) + 1e-12
        r = np.abs(Xc.T @ yc) / den
        self.j = int(np.argmax(r))
        self.p = np.polyfit(X[:, self.j], y, 1)
        return self

    def predict(self, X):
        return np.polyval(self.p, X[:, self.j])


class MeanBaseline:
    """Predicts the training mean. A model must beat this to be of any use."""
    def fit(self, X, y):
        self.mu = float(np.mean(y)); return self

    def predict(self, X):
        return np.full(len(X), self.mu)
