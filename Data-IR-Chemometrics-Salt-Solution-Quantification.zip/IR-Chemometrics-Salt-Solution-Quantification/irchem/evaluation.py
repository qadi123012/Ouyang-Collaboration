"""Cross-validation and external validation helpers."""
import numpy as np
from .models import PLS1, Univariate, MeanBaseline


def rmse(y, p):
    return float(np.sqrt(np.mean((np.asarray(y) - np.asarray(p)) ** 2)))


def r2(y, p):
    y, p = np.asarray(y), np.asarray(p)
    sst = np.sum((y - y.mean()) ** 2)
    return float(1 - np.sum((y - p) ** 2) / sst) if sst > 0 else np.nan


def logo_predict(make_model, X, y, groups):
    """Leave-one-group-out predictions. Groups are physical samples, so replicates never straddle a split."""
    pred = np.empty(len(y))
    for g in np.unique(groups):
        te = groups == g
        pred[te] = make_model().fit(X[~te], y[~te]).predict(X[te])
    return pred


def pls_cv_curve(X, y, groups, kmax=8):
    """RMSECV for 1..kmax latent variables."""
    kmax = int(min(kmax, len(np.unique(groups)) - 2, X.shape[1]))
    return np.array([rmse(y, logo_predict(lambda k=k: PLS1(k), X, y, groups)) for k in range(1, kmax + 1)])


def choose_k(curve, tol=0.05):
    """Parsimonious choice: the smallest number of latent variables whose RMSECV is within `tol` of the minimum."""
    curve = np.asarray(curve)
    return int(np.where(curve <= curve.min() * (1 + tol))[0][0]) + 1


def metrics(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    return dict(rmse=rmse(y, p), mae=float(np.mean(np.abs(y - p))), bias=float(np.mean(p - y)), r2=r2(y, p),
                rel_rmse_pct=float(100 * rmse(y, p) / max(np.ptp(y), 1e-12)))
