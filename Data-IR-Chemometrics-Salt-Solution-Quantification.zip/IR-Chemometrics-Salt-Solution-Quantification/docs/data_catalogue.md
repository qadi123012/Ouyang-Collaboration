# Data catalogue

Eleven spectral workbooks are used by the code (`irchem/io.py` registry). The table is generated from `results/tables/data_catalogue.csv`. File names under `data/raw/` were cleaned; the original names are given so every file can be traced back.

| Key | System | Status | File in `data/raw/` | Original file name | Spectra (cal / val) | Range (cm-1) | Removed windows |
|---|---|---|---|---|---|---|---|
| `k2co3_khco3` | K2CO3 + KHCO3 | primary | `k2co3_khco3/k2co3_khco3_v3_corrected.xlsx` | Correct_ OUYANG-K2CO3 mix KHCO3 data.xlsx | 16 (11 / 5) | 552 to 4000 | none |
| `oxalate` | K2C2O4 + KHC2O4 | primary | `potassium_oxalate/k2c2o4_khc2o4.xlsx` | New_3_ 3.6-OUYANG-K2C2O4 mix KHC2O4 data.xlsx | 16 (11 / 5) | 552 to 4000 | none |
| `ammonium_sulfate` | (NH4)2SO4 + NH4HSO4 | primary | `ammonium_sulfate_bisulfate/as_abs_v3_full_range.xlsx` | new_new-3.6-OUYANG-(NH4)2SO4 mix NH4HSO4 data.xlsx | 20 (11 / 9) | 552 to 4000 | none |
| `phosphate` | Na3PO4 + Na2HPO4 + NaH2PO4 | primary | `sodium_phosphate/na3po4_na2hpo4_nah2po4.xlsx` | NEW 3.6-OUYANG-Na3PO4 mix Na2HPO4 mix NaH2PO4 data.xlsx | 22 (17 / 5) | 552 to 4000 | none |
| `k2co3_khco3_v2` | K2CO3 + KHCO3 (earlier version, 399-4000 cm-1) | earlier version | `k2co3_khco3/k2co3_khco3_v2_extended_range.xlsx` | exp-OUYANG-mix solution data.xlsx | 16 (11 / 5) | 399 to 4000 | none |
| `k2co3_khco3_v1` | K2CO3 + KHCO3 (original, 900-2000 cm-1) | earlier version | `k2co3_khco3/k2co3_khco3_v1_original_900-2000.xlsx` | origin 2.26-OUYANG-mix solution data.xlsx | 16 (11 / 5) | 901 to 2000 | none |
| `as_abs_cuta` | (NH4)2SO4 + NH4HSO4, CO2 window removed | variant | `ammonium_sulfate_bisulfate/as_abs_v2_co2_window_removed.xlsx` | cuta-3.6-OUYANG-(NH4)2SO4 mix NH4HSO4 data(1).xlsx | 20 (11 / 9) | 552 to 4000 | [(2222.0, 2434.0)] |
| `as_abs_cut` | (NH4)2SO4 + NH4HSO4, 874-984 cm-1 removed | variant | `ammonium_sulfate_bisulfate/as_abs_v1_874-984_removed.xlsx` | cut-3.6-OUYANG-(NH4)2SO4 mix NH4HSO4 data.xlsx | 20 (11 / 9) | 552 to 4000 | [(874.0, 984.0)] |
| `as_abs_4p1` | (NH4)2SO4 + NH4HSO4, calibration only | variant | `ammonium_sulfate_bisulfate/as_abs_4p1_R_only.xlsx` | 4.1-OUYANG-(NH4)2SO4.xlsx | 11 (11 / 0) | 552 to 4000 | [(2218.0, 2452.0)] |
| `as_abs_4p1_cut` | (NH4)2SO4 + NH4HSO4, calibration only, CO2 window removed | variant | `ammonium_sulfate_bisulfate/as_abs_4p1_R_only_co2_window_removed.xlsx` | 4.1-3 times-cutY-cut2220-2430-(NH4)2SO4.xlsx | 11 (11 / 0) | 552 to 4000 | [(2220.0, 2430.0)] |
| `as_abs_4p6` | (NH4)2SO4 + NH4HSO4, triplicates (water background) | variant | `ammonium_sulfate_bisulfate/as_abs_4p6_water_background_triplicates.xlsx` | 4.6-waterbg-3 times-cutY-cut2220-2430-(NH4)2SO4(1).xlsx | 33 (33 / 0) | 552 to 4000 | [(2220.0, 2430.0)] |

Spectra and standards are not the same thing in `as_abs_4p6`: it holds 33 spectra of 11 standards (every standard was measured three times).

## Things to know about the files

1. **Template headers.** `ammonium_sulfate*`, `as_abs_*` and `oxalate` still read `c_K2CO3` / `c_KHCO3`. The first column is component 1 (the salt named first in the file name), the second is component 2.
2. **Two K2CO3 + KHCO3 generations.** `k2co3_khco3` (corrected) differs from `k2co3_khco3_v2` in exactly two spectra, R3 and R10. In the earlier file they are 0.75 / 0.75 mol/L mixtures, in the corrected file they are blanks with different spectra (maximum signal difference about 28). All other spectra are identical. Results from v1 and v2 are therefore not comparable with the corrected file, and they are reported only for completeness (`results/tables/k2co3_khco3_label_comparison_v2_vs_v3.csv`).
3. **First rows.** The sample table and the first 16 spectral points share the same sheet rows. The MATLAB scripts that read `Sheet1` directly split rows by "name is empty" and so silently drop the first 16 spectral points (about 551 to 580 cm-1). The Python loader keeps them.
4. **Unused sheets.** The sulfate workbooks have a `Sheet2` (columns R-1 ... R-12) and a `Sheet3` (columns such as `AS/ABS=1/10`, wavenumber grid from 399 cm-1, values up to about 1000). Their meaning is not documented in the files and they are not used.
5. **Calibration design.** Each system has 11 to 17 standards on a roughly factorial grid, with one replicated centre composition (three blanks in K2CO3 + KHCO3, three 0.25/0.25 standards in oxalate, three 1.0/1.0 standards in sulfate, three 0.25/0.25/0.25 in phosphate). That is a small calibration set for 1700 spectral variables.
6. **Validation samples.** Y1 to Y5 (carbonate, oxalate, phosphate) are intermediate compositions. Y1 to Y9 in the sulfate file lie on a mixing line whose labelled concentrations sum to 1.0 mol/L.
7. **CO2 window.** The atmospheric CO2 doublet near 2350 cm-1 produces a spike in the raw spectra. Several workbooks have the window 2220 to 2430 cm-1 cut out; the pipeline excludes it everywhere.
