# Methods

This document explains exactly what `irchem/` and `scripts/` compute, so the results can be checked and repeated.

## 1. Data and labels

Each workbook (`data/raw/...`) stores, in `Sheet1`, a table of standards and one infrared spectrum per standard.

* `R1 ... R17` are **calibration standards** and `Y1 ... Y9` are **validation samples**. Y samples are never used to fit a model or to pick any setting.
* The recorded signal behaves like **percent transmittance**: it sits near 97 to 100 outside the bands and bands appear as dips (water O-H near 3300 cm-1, H-O-H bend near 1640 cm-1, the CO2 spike near 2350 cm-1). The files call it "absorption"; one header says `unit:%`. Because the Beer-Lambert law is linear in absorbance, `A = -log10(T/100)` is offered as an alternative to the recorded values.
* Concentrations are in mol/L. Columns are read **by position**: the first concentration column is component 1. Several workbooks still carry the template headers `c_K2CO3` and `c_KHCO3` although they hold other salts, so the registry in `irchem/io.py` states the real chemistry.
* Standards prepared at identical concentrations (centre points such as R2/R5/R9 in the sulfate set) are given the same **composition group**.

## 2. Pre-processing (`irchem/preprocessing.py`)

| Step | Options | Notes |
|---|---|---|
| signal | `T` as recorded, `A` absorbance | `A = -log10(T/100)`, values below 0.5 % are floored |
| derivative | none, or Savitzky-Golay 1st derivative (window 15, order 2) | applied on contiguous stretches only, so a removed window never creates a spike |
| region | `full` 650 to 4000, `wide` 650 to 2000, `fingerprint` 800 to 1800 cm-1 | the CO2 window 2220 to 2430 cm-1 is always excluded |
| scatter correction | none, or SNV | standard normal variate per spectrum, computed after the region is chosen |

This gives 2 x 2 x 2 x 3 = 24 pipelines. A pipeline label reads `signal|region|scatter|derivative`, for example `A|fingerprint|snv|d0`.

`ipf_baseline` is a Python port of the iterative polynomial baseline used in `matlab/preprocess_spectra.m`. It is available but not part of the benchmark grid.

## 3. Models (`irchem/models.py`)

* **PLS1**: partial least squares regression, one model per analyte, mean-centred, no variance scaling (scikit-learn `PLSRegression`). The three-component phosphate system therefore has three separate models.
* **Univariate**: the single wavenumber with the highest absolute correlation to the analyte, then a straight line. The wavenumber is re-selected inside every cross-validation fold, so the baseline is not flattered.
* **Mean baseline**: predicts the training mean. A model that cannot beat this is not predicting anything.

The MATLAB scripts fit a joint PLS2 model. PLS1 is used here because each analyte can then have its own model size.

## 4. Validation protocol (`scripts/02_run_benchmark.py`)

1. Calibration set = R spectra. Validation set = Y spectra (when present).
2. For each pipeline and analyte, **leave-one-composition-out** cross-validation on the calibration set gives RMSECV for 1 to 8 latent variables. All spectra with the same composition are held out together. Ordinary leave-one-out would keep a near duplicate of every centre point in the training data and report an optimistic error.
3. The number of latent variables is the smallest whose RMSECV is within 5 % of the minimum (parsimony rule).
4. The final model is fitted on all calibration spectra and applied **once** to the validation spectra.
5. The pipeline called "best" is chosen by **normalised RMSECV only** (RMSECV divided by the SD of the calibration concentrations, averaged over analytes). Validation errors of all 24 pipelines are still tabulated, so one can see how well CV predicts them.

### Metrics

| Symbol | Meaning |
|---|---|
| RMSEC, R2 (cal) | error of the model on the data it was fitted to; a fit statistic, not a prediction measure |
| RMSECV, R2 (cv) | leave-one-composition-out prediction error on the calibration set |
| RMSEP, R2 (val) | error on the unseen Y samples |
| mean baseline | RMSEP of predicting the calibration mean |
| corr, slope (val) | Pearson r and slope of predicted versus labelled concentration on Y; separates a **scale** problem (r near 1, slope far from 1) from a **noise** problem (low r) |

With 5 to 9 validation samples, R2 (val) is noisy and can be strongly negative when predictions are biased. Read it together with RMSEP and the baseline.

## 5. Audit of the MATLAB-style statistics (`scripts/04_metric_audit_vs_matlab.py`)

Reproduces the recipe of the MATLAB PLS scripts (all samples, raw spectra, joint PLS2, random 5-fold CV for model size, R2 of the fitted data) and sets it beside the protocol above. The Python version is MATLAB-style, not bit-identical.

## 6. Reproducibility

Random numbers are used only in the 5-fold CV of the audit (fixed seed 0). Everything else is deterministic. `bash run_all.sh` regenerates every table and figure in about 75 seconds on one CPU core.
