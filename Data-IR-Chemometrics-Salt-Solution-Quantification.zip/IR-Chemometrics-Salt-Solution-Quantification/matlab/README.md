# matlab/

The original MATLAB scripts, copied unchanged and renamed so that the file name says what each one does. They are interactive: most ask for a workbook through `uigetfile`. They need the Statistics and Machine Learning Toolbox (`plsregress`, `fitlm`, `cvpartition`).

| File (new name) | Original name | What it does |
|---|---|---|
| `preprocess_spectra.m` | `preprocessing_data.m` | Reads a workbook and writes `*_PREPROCESSED.xlsx` with IPF baseline correction, Savitzky-Golay smoothing and SNV (default: SNV). Outputs of this step are in `data/processed/` |
| `pls_regression_basic.m` | `ouyung_PLSR_Algorithem.m` | Joint PLS2 on all samples of a workbook, components chosen by k-fold CV, parity and spectrum plots |
| `pls_regression_with_cls.m` | `new.m` | The same plus a classical least squares (CLS) comparison |
| `pls_cls_all_plots.m` | `all_graphs.m` | PLS and CLS with the full set of plots |
| `pls_cls_replicate_averaging.m` | `ouyang_2nd_option_code.m` | PLS and CLS after averaging replicate spectra, fixed CV partition |
| `pls_on_preprocessed_file.m` | `postprocessing_data.m` | PLS on the `Metadata` and `Spectra` sheets written by `preprocess_spectra.m` |
| `pls_train_and_predict_unknowns.m` | `old.m` | Trains on a standards workbook and predicts a second workbook without concentrations, writes `Predicted_Concentrations.xlsx` |
| `univariate_calibration_demo.m` | `onyung_colaboration.m` | Single-wavenumber calibration (default 1000 cm-1) with `fitlm`, and a per-point prediction demo |
| `total_concentration_regression.m` | `tang_chen_project.m` | Regresses total concentration on (wavenumber, mean absorption) pairs and checks predictions against reference values with a tolerance band; reads two CSV files that are not in this repository |

## Known issues

These do not change the files here; they explain why `scripts/` reimplements the analysis.

1. **The printed R2 and RMSE are fit statistics.** Models are fitted on all samples of the sheet, including the Y samples, and then scored on the same data. See `docs/findings_and_limitations.md`.
2. **The first 16 spectral points are dropped.** Rows are split with "name is empty", but the sample table sits in the first 16 rows of the same sheet, so those rows are treated as metadata (about 551 to 580 cm-1).
3. **Random CV folds.** `pls_regression_basic.m` calls `cvpartition` inside the loop over the number of components, so each model size is scored on different folds even with `rng(0)`, and the choice of components is partly noise. `pls_cls_replicate_averaging.m` creates the partition once.
4. **Joint PLS2.** One component count is shared by all analytes.
5. **Hard-coded values.** `total_concentration_regression.m` contains fixed reference concentrations and a tolerance band; it also treats every wavenumber as an observation, which is not a conventional calibration.
6. **Missing inputs.** `total_concentration_regression.m` expects the "4.9-standard" and "4.9-predict" CSV files, which were not provided.
