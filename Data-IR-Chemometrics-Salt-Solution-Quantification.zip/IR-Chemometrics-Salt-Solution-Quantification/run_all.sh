#!/usr/bin/env bash
# Regenerate every table and figure. About 75 seconds on one CPU core.
set -euo pipefail
cd "$(dirname "$0")"
python -m pytest -q tests
python scripts/01_describe_datasets.py > results/tables/log_01_catalogue.txt
python scripts/02_run_benchmark.py     > results/tables/log_02_benchmark.txt
python scripts/03_make_figures.py      > results/tables/log_03_figures.txt
python scripts/04_metric_audit_vs_matlab.py > results/tables/log_04_audit.txt
echo "Done. See results/tables and results/figures."
