"""Fast tests:  python -m pytest -q tests"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import numpy as np
import pytest
from irchem import io, preprocessing as P, evaluation as E
from irchem.models import PLS1, Univariate, MeanBaseline


@pytest.mark.parametrize("key", list(io.REGISTRY))
def test_every_dataset_loads_consistently(key):
    ds = io.load(key)
    assert ds.X.shape == (len(ds.names), len(ds.wn))
    assert ds.Y.shape == (len(ds.names), len(ds.components))
    assert np.all(np.diff(ds.wn) > 0)
    assert ds.is_cal.sum() + ds.is_val.sum() == len(ds.names)
    assert np.isfinite(ds.X).all() and np.isfinite(ds.Y).all()


def test_expected_sample_counts():
    assert io.load("k2co3_khco3").is_cal.sum() == 11 and io.load("k2co3_khco3").is_val.sum() == 5
    assert io.load("phosphate").Y.shape[1] == 3
    assert io.load("ammonium_sulfate").is_val.sum() == 9
    tri = io.load("as_abs_4p6")
    assert len(tri.names) == 33 and tri.n_samples == 11          # triplicates share a sample id


def test_replicated_compositions_share_a_group():
    ds = io.load("k2co3_khco3")                                  # R3, R4, R10 are all blanks
    g = {n: gi for n, gi in zip(ds.names, ds.groups)}
    assert g["R3"] == g["R4"] == g["R10"]


def test_absorbance_conversion():
    assert np.isclose(P.to_absorbance(np.array([100.0]))[0], 0.0)
    assert np.isclose(P.to_absorbance(np.array([10.0]))[0], 1.0)
    assert np.isfinite(P.to_absorbance(np.array([0.0]))[0])      # floor prevents log(0)


def test_snv_gives_zero_mean_unit_sd():
    Z = P.snv(np.random.default_rng(0).normal(5, 2, (4, 50)))
    assert np.allclose(Z.mean(1), 0) and np.allclose(Z.std(1, ddof=1), 1)


def test_region_selection_removes_co2_window():
    wn = np.linspace(600, 4000, 1800)
    w, _ = P.select_region(wn, np.zeros((1, len(wn))), "full")
    assert not np.any((w >= 2220) & (w <= 2430)) and w.min() >= 650


def test_savgol_derivative_respects_gaps():
    wn = np.r_[np.arange(600, 1000, 2.0), np.arange(1200, 1600, 2.0)]
    X = np.vstack([wn * 0.01])                                   # straight line: derivative is constant
    d = P.savgol_per_segment(wn, X, window=15, poly=2, deriv=1)
    assert np.allclose(d, 0.02, atol=1e-6)                       # no spike where the window was removed


def test_pipeline_output_shapes():
    ds = io.load("oxalate")
    w, Z = P.Pipeline("A", "snv", 1, "fingerprint").apply(ds.wn, ds.X)
    assert Z.shape == (len(ds.names), len(w)) and w.min() >= 800 and w.max() <= 1800


def test_pls_recovers_a_synthetic_two_component_mixture():
    rng = np.random.default_rng(1)
    S = rng.random((2, 200)); C = rng.random((30, 2)) * 2
    X = C @ S + rng.normal(0, 1e-3, (30, 200))
    m = PLS1(2).fit(X[:20], C[:20, 0])
    assert E.rmse(C[20:, 0], m.predict(X[20:])) < 0.01


def test_baselines_and_choose_k():
    X = np.arange(20.0).reshape(10, 2); y = np.arange(10.0)
    assert np.isclose(MeanBaseline().fit(X, y).predict(X)[0], y.mean())
    assert Univariate().fit(X, y).j in (0, 1)
    assert E.choose_k([0.5, 0.31, 0.30, 0.299, 0.4]) == 2        # smallest k within 5 % of the minimum


def test_group_cv_never_splits_a_group():
    X = np.random.default_rng(2).normal(size=(9, 5)); y = np.arange(9.0)
    groups = np.array([0, 0, 0, 1, 2, 3, 4, 5, 6])
    seen = []
    class Spy(MeanBaseline):
        def fit(self, X_, y_):
            seen.append(len(y_)); return super().fit(X_, y_)
    E.logo_predict(Spy, X, y, groups)
    assert 6 in seen and 8 in seen                               # group 0 (3 spectra) is held out together
