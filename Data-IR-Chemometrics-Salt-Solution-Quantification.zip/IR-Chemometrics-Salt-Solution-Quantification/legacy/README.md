# legacy/

Material from the original repository whose code or inputs are **not** fully available. It is kept for the record and is not used by the current pipeline. Treat the numbers in it as exploratory.

## original_outputs/

Figures and a report from an earlier analysis (peak fitting, linear calibration on peak height or area, and an artificial neural network). The code that produced the ANN figures (`ann_*.png`, `concentration_heatmap.png`, `feature_importance.png`, `correlation_matrix.png`) is not in the repository.

| File | What it shows | Caveat |
|---|---|---|
| `calibration_k2co3.png`, `calibration_khco3.png` | Predicted versus known concentration, R2 = 0.745 and 0.587 | weak calibrations, whatever the points represent |
| `concentration_prediction_plot.png` | Linear fit on one peak (576.7 cm-1) and predictions for unknowns | predicted values go **negative** (down to about -2 mol/L), so the unknowns are outside the calibration domain |
| `final_calibration_curves.png` | Peak-area calibrations at 2195.0 and 665.4 cm-1 | each line is drawn through only **two** points, so it carries no statistical information; 2195 cm-1 lies next to the CO2 window |
| `ann_*.png`, `concentration_*.png`, `feature_importance.png`, `correlation_matrix.png` | ANN predictions by sample, training history, spectral importance | the report lists 22 training samples; no held-out evaluation is shown |
| `concentration_prediction_report.txt` | Report with 3 fitted peaks, 22 training and 38 prediction samples | the file stops after the heading "K2CO3 Model:" |

## original_python/

* `univariate_peak_calibration.py`: the script `calibration_and_prediction.py` (per-peak linear calibration). It reads `0611-train-new.xlsx` and a prediction workbook that are not in the repository.
* `peak_detection_plsr.py`: the code from `Code with peaks.docx` (peak detection, then PLSR). Two issues: the number of PLS components is chosen by the **training** error, which always selects the largest model, and no cross-validation or held-out set is used. The input workbooks (`0611-train-new.xlsx`, `0611-verify & predict-new.xlsx`) are not in the repository.

## Naming

The original README titled the work "Machine Learning (CNN) Approach". No convolutional network exists in the files; the methods present are PLS regression, classical least squares, univariate calibration, and (output only) an ANN. The project name and description were changed to match what the repository contains.
