"""Peak detection + PLSR script as found in `Code with peaks.docx` (extracted from the .docx; non-breaking spaces replaced by normal spaces, nothing else changed).

NOT RUNNABLE AS SHIPPED: it reads 0611-train-new.xlsx and "0611-verify & predict-new.xlsx", which are not in
the repository. See legacy/README.md for the known issues (components chosen by training error, etc.).
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter
from sklearn.cross_decomposition import PLSRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score
import seaborn as sns

# Load training data
print("Loading and preprocessing data...")
train = pd.read_excel('0611-train-new.xlsx')
train_wavenumber = train['wave number']

# Load prediction data
pred = pd.read_excel('0611-verify & predict-new.xlsx')
pred_wavenumber = pred['wave number']

# Get column names
pred_abs_cols = [col for col in pred.columns if col != 'wave number']
train_abs_cols = [col for col in train.columns if col not in ['name', 'c_K2CO3', 'c_KHCO3', 'Total', 'wave number']]

print(f"\nProcessing {len(pred_abs_cols)} unknown samples...")

# Handle missing values
train = train.fillna(method='ffill').fillna(method='bfill')
pred = pred.fillna(method='ffill').fillna(method='bfill')

# Function to smooth spectra and find major peaks
def process_spectrum(spectrum, window=51, polyorder=3, prominence=0.5, width=10):
    # Apply Savitzky-Golay filter for smoothing
    spectrum_smooth = savgol_filter(spectrum, window, polyorder)
    
    # Find peaks with more stringent criteria
    peaks, properties = find_peaks(spectrum_smooth, 
                                 prominence=prominence,
                                 width=width,
                                 height=np.mean(spectrum_smooth))
    
    return spectrum_smooth, peaks, properties

# Plot all absorption spectra for training file with major peaks
plt.figure(figsize=(16, 10))
for col in train_abs_cols:
    spectrum = train[col].values
    spectrum_smooth, peaks, _ = process_spectrum(spectrum)
    plt.plot(train_wavenumber, spectrum_smooth, label=col, alpha=0.7)
    plt.plot(train_wavenumber.iloc[peaks], spectrum_smooth[peaks], 'rx')
plt.xlabel('Wavenumber')
plt.ylabel('Absorbance')
plt.title('Training File: All Absorption Spectra (Smoothed)')
plt.legend(fontsize=7, ncol=3)
plt.tight_layout()
plt.savefig('train_all_spectra_smooth.png', dpi=300)
plt.close()

# Plot peaks for each absorption column in training file
for col in train_abs_cols:
    plt.figure(figsize=(8, 4))
    spectrum = train[col].values
    spectrum_smooth, peaks, _ = process_spectrum(spectrum)
    
    plt.plot(train_wavenumber, spectrum_smooth, label='Smoothed spectrum')
    plt.plot(train_wavenumber.iloc[peaks], spectrum_smooth[peaks], 'rx', label='Major Peaks')
    plt.xlabel('Wavenumber')
    plt.ylabel('Absorbance')
    plt.title(f'Training: {col} Major Peaks')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f'train_peaks_{col}.png', dpi=200)
    plt.close()

# Plot all absorption spectra for prediction file with major peaks
plt.figure(figsize=(16, 10))
for col in pred_abs_cols:
    spectrum = pred[col].values
    spectrum_smooth, peaks, _ = process_spectrum(spectrum)
    plt.plot(pred_wavenumber, spectrum_smooth, label=col, alpha=0.7)
    plt.plot(pred_wavenumber.iloc[peaks], spectrum_smooth[peaks], 'rx')
plt.xlabel('Wavenumber')
plt.ylabel('Absorbance')
plt.title('Prediction File: All Absorption Spectra (Smoothed)')
plt.legend(fontsize=7, ncol=3)
plt.tight_layout()
plt.savefig('predict_all_spectra_smooth.png', dpi=300)
plt.close()

# Plot peaks for each absorption column in prediction file
for col in pred_abs_cols:
    plt.figure(figsize=(8, 4))
    spectrum = pred[col].values
    spectrum_smooth, peaks, _ = process_spectrum(spectrum)
    
    plt.plot(pred_wavenumber, spectrum_smooth, label='Smoothed spectrum')
    plt.plot(pred_wavenumber.iloc[peaks], spectrum_smooth[peaks], 'rx', label='Major Peaks')
    plt.xlabel('Wavenumber')
    plt.ylabel('Absorbance')
    plt.title(f'Prediction: {col} Major Peaks')
    plt.legend()
    plt.tight_layout()
    plt.savefig(f'predict_peaks_{col}.png', dpi=200)
    plt.close()

# Prepare training data for PLSR
# Transpose the data to get samples as rows
X_train = train[train_abs_cols].T.values
Y_train = train[['c_K2CO3', 'c_KHCO3']].iloc[:len(train_abs_cols)].values

scaler_X = StandardScaler()
scaler_Y = StandardScaler()
X_train_scaled = scaler_X.fit_transform(X_train)
Y_train_scaled = scaler_Y.fit_transform(Y_train)

# Find optimal number of components
max_components = min(10, min(X_train.shape))
mse_values = []
for n_comp in range(1, max_components + 1):
    pls = PLSRegression(n_components=n_comp)
    pls.fit(X_train_scaled, Y_train_scaled)
    Y_pred = pls.predict(X_train_scaled)
    mse = np.mean((Y_train_scaled - Y_pred) ** 2)
    mse_values.append(mse)

optimal_components = np.argmin(mse_values) + 1
print(f"\nOptimal number of PLS components: {optimal_components}")

# Fit final PLSR model
pls = PLSRegression(n_components=optimal_components)
pls.fit(X_train_scaled, Y_train_scaled)

# Training performance
Y_train_pred_scaled = pls.predict(X_train_scaled)
Y_train_pred = scaler_Y.inverse_transform(Y_train_pred_scaled)
r2_train_k2co3 = r2_score(Y_train[:, 0], Y_train_pred[:, 0])
r2_train_khco3 = r2_score(Y_train[:, 1], Y_train_pred[:, 1])

print("\nTraining Set Performance:")
print(f"R² score for K2CO3: {r2_train_k2co3:.3f}")
print(f"R² score for KHCO3: {r2_train_khco3:.3f}")

# Predict concentrations for each sample
predictions = []
for sample in pred_abs_cols:
    # Get spectrum for this sample and transpose it
    spectrum = pred[sample].values.reshape(1, -1)
    
    # Scale the spectrum
    spectrum_scaled = scaler_X.transform(spectrum)
    
    # Predict concentrations
    pred_conc_scaled = pls.predict(spectrum_scaled)
    pred_conc = scaler_Y.inverse_transform(pred_conc_scaled)
    
    # Ensure non-negative concentrations
    pred_conc = np.maximum(pred_conc, 0)
    
    predictions.append({
        'Sample': sample,
        'Predicted_K2CO3': pred_conc[0, 0],
        'Predicted_KHCO3': pred_conc[0, 1],
        'Total_Concentration': pred_conc[0, 0] + pred_conc[0, 1]
    })

# Create results DataFrame
results_df = pd.DataFrame(predictions)
results_df = results_df.sort_values('Total_Concentration', ascending=False)

# Print summary statistics
print("\nPredicted Concentration Summary Statistics:")
print(results_df[['Predicted_K2CO3', 'Predicted_KHCO3', 'Total_Concentration']].describe())

# Save detailed results
print("\nSaving detailed results to 'predicted_concentrations_detailed.xlsx'...")
results_df.to_excel('predicted_concentrations_new.xlsx', index=False)

# Create heatmap
plt.figure(figsize=(12, 8))
plt.title('Predicted Concentrations Heatmap')
sns.heatmap(results_df[['Predicted_K2CO3', 'Predicted_KHCO3']].values.reshape(-1, 2),
            annot=True,
            fmt='.3f',
            xticklabels=['K2CO3', 'KHCO3'],
            yticklabels=results_df['Sample'],
            cmap='YlOrRd')
plt.tight_layout()
plt.savefig('concentration_heatmap.png', dpi=300, bbox_inches='tight')
plt.close()

# Plot concentration distribution
plt.figure(figsize=(10, 6))
scatter = plt.scatter(results_df['Predicted_K2CO3'], results_df['Predicted_KHCO3'],
                     c=results_df['Total_Concentration'], cmap='viridis')
plt.colorbar(scatter, label='Total Concentration')
plt.xlabel('Predicted K2CO3 Concentration')
plt.ylabel('Predicted KHCO3 Concentration')
plt.title('Distribution of Predicted Concentrations')
plt.grid(True)
plt.tight_layout()
plt.savefig('concentration_distribution.png', dpi=300)
plt.close()

# Print top 10 highest total concentration samples
print("\nTop 10 Samples by Total Concentration:")
print(results_df.head(10).to_string(index=False))

# Save comprehensive report
print("\nSaving comprehensive report to 'concentration_prediction_report.txt'...")
with open('concentration_prediction_report.txt', 'w') as f:
    f.write("Concentration Prediction Report\n")
    f.write("============================\n\n")
    f.write(f"Model Parameters:\n")
    f.write(f"- Number of PLS components: {optimal_components}\n")
    f.write(f"- Training R² (K2CO3): {r2_train_k2co3:.3f}\n")
    f.write(f"- Training R² (KHCO3): {r2_train_khco3:.3f}\n\n")
    f.write("Summary Statistics:\n")
    f.write(results_df.describe().to_string())
    f.write("\n\nDetailed Predictions:\n")
    f.write(results_df.to_string())
    
print("\nAnalysis complete! Check the following files for results:")
print("1. predicted_concentrations_detailed.xlsx - Detailed predictions for all samples")
print("2. concentration_heatmap.png - Visual representation of predicted concentrations")
print("3. concentration_distribution.png - Distribution of predicted concentrations")
print("4. concentration_prediction_report.txt - Comprehensive report with all details")
